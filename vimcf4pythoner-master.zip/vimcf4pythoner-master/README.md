# vimcf4pythoner
A vim config set for pythoner
